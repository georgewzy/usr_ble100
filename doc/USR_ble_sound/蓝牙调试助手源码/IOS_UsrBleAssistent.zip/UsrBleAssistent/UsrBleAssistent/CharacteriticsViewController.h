//
//  CharacteriticsViewControllerTableViewController.h
//  UsrBleAssistent
//
//  Created by USRCN on 15-12-8.
//  Copyright (c) 2015年 usr.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CBManager.h"

@interface CharacteriticsViewController : UITableViewController<cbCharacteristicManagerDelegate>

@end
