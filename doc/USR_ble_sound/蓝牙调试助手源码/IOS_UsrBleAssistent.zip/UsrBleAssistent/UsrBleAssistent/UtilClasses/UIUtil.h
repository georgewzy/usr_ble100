//
//  UIUtil.h
//  AMiTime
//
//  Created by liu on 15/4/20.
//  Copyright (c) 2015年 usr.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface UIUtil : NSObject

+ (void) shakeAction:(UIView *) shakeView;

@end
